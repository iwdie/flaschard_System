# Watermelon Fusion

Watermelon merge mobile game developed in Godot 3.5

## Screenshots

<img src="https://github.com/koopmyers/watermelon-fusion/assets/16466001/dfbbf201-f7b8-4bed-84fd-79e197470200" alt="drawing" width="200"/>
<img src="https://github.com/koopmyers/watermelon-fusion/assets/16466001/8f8b707e-d622-415a-a45f-6d80cd6dcc84" alt="drawing" width="200"/>
<img src="https://github.com/koopmyers/watermelon-fusion/assets/16466001/7371dc72-4430-4fbd-98b5-09a1d48b99d1" alt="drawing" width="200"/>


## Licence
<p xmlns:cc="http://creativecommons.org/ns#" xmlns:dct="http://purl.org/dc/terms/"><a property="dct:title" rel="cc:attributionURL" href="https://github.com/koopmyers/watermelon-fusion">Watermelon Fusion</a> by <a rel="cc:attributionURL dct:creator" property="cc:attributionName" href="https://github.com/koopmyers">Koop Myers</a> is licensed under <a href="http://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">Attribution-NonCommercial-ShareAlike 4.0 International<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1"><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1"><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/nc.svg?ref=chooser-v1"><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/sa.svg?ref=chooser-v1"></a></p>
